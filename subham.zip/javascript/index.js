
$(document).ready(function(){
    $('#menu').click(function(){
     $(this).toggleClass('fa-times')
    // for toogle heder class
     $('header').toggleClass('toggle');
    });
});

